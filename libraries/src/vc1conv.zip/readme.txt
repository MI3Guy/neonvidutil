vc1conv VC-1 Elementary Stream Converter 0.4

Changes for 0.4

1) Increased buffer size to handle large picture in "Mr. Beans Holiday".

Changes for 0.3

1) Removed dependency on POSTPROCFLAG being equal to zero.
2) Removed setting of POSTPROCFLAG and adding POSTPROC bits.
3) Made bitrate display accurate.
4) Put frame count back in, and added running time.

Usage is:

vc1conv <infile> <outfile>

typically:

vc1conv bits0001.mpv vc1prog.mpv

This program converts an interlaced 29.97 fps with pulldown flags VC-1
elementary video stream (from HD DVD) to a progressive 23.976 fps VC-1
elementary stream (for Blu-ray and other purposes). Specifically, it
performs the following operations for each occurance in the bitstream:

1) Change INTERLACE from 1 to 0.
2) Change FRAMERATENR from 3 (30 * 1000) to 1 (24 * 1000).
3) Remove FCM.
4) Set RPTFRM to 0.
5) Remove UVSAMP.
